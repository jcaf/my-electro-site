from fastapi import APIRouter, Depends, UploadFile, File
from sqlalchemy.orm import Session
from database import get_db
from models.project import Project
from models.project_media import ProjectMedia
from pydantic import BaseModel
from typing import List
import shutil, os
from datetime import datetime

router = APIRouter(prefix="/projects", tags=["Projects"])

UPLOAD_DIR = "uploads/projects"

# ---------- SCHEMAS ----------
class ProjectCreate(BaseModel):
    titulo: str
    descripcion: str

class ProjectOut(BaseModel):
    id: int
    titulo: str
    descripcion: str
    fecha_creacion: datetime

    class Config:
        from_attributes = True

# ---------- ENDPOINTS PROYECTOS ----------
@router.get("/", response_model=List[ProjectOut])
def get_projects(db: Session = Depends(get_db)):
    return db.query(Project).all()

@router.get("/{project_id}", response_model=ProjectOut)
def get_project(project_id: int, db: Session = Depends(get_db)):
    return db.query(Project).filter(Project.id == project_id).first()

@router.post("/", response_model=ProjectOut)
def create_project(project: ProjectCreate, db: Session = Depends(get_db)):
    db_project = Project(**project.dict())
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project

# ---------- ENDPOINTS MEDIA ----------
@router.post("/{project_id}/media")
def upload_project_media(
    project_id: int,
    tipo: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = f"{UPLOAD_DIR}/{project_id}_{file.filename}"
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    media = ProjectMedia(project_id=project_id, file_path=file_path, tipo=tipo)
    db.add(media)
    db.commit()
    db.refresh(media)
    return {"msg": "Archivo subido", "file_path": file_path}

@router.get("/{project_id}/media")
def get_project_media(project_id: int, db: Session = Depends(get_db)):
    return db.query(ProjectMedia).filter(ProjectMedia.project_id == project_id).all()
