from sqlalchemy import Column, Integer, String, DateTime
from database import Base
from datetime import datetime
from sqlalchemy.orm import relationship

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    titulo = Column(String, nullable=False)
    descripcion = Column(String, nullable=False)
    imagen_path = Column(String, nullable=True)   # <- guarda la ruta del archivo subido
    video_path = Column(String, nullable=True)
    fecha_creacion = Column(DateTime, default=datetime.utcnow)
    media = relationship("ProjectMedia", back_populates="project", cascade="all, delete-orphan")