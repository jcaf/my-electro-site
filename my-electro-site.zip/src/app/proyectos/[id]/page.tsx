"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";

interface Media {
  id: number;
  file_path: string;
  tipo: string;
}

interface Project {
  id: number;
  titulo: string;
  descripcion: string;
}

export default function ProyectoDetalle() {
  const params = useParams();
  const id = params?.id;
  const [project, setProject] = useState<Project | null>(null);
  const [media, setMedia] = useState<Media[]>([]);

  useEffect(() => {
    if (!id) return;

    // Obtener datos del proyecto
    fetch(`http://localhost:8000/projects/${id}`)
      .then((res) => res.json())
      .then(setProject);

    // Obtener galería multimedia
    fetch(`http://localhost:8000/projects/${id}/media`)
      .then((res) => res.json())
      .then(setMedia);
  }, [id]);

  if (!project) return <p className="text-white p-10">Cargando proyecto...</p>;

  return (
    <>
      <Navbar />
      <main className="bg-gray-900 min-h-screen text-white p-10">
        <div className="max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl font-bold text-cyan-400">{project.titulo}</h1>
          <p className="text-gray-300">{project.descripcion}</p>

          {media.length > 0 && (
            <Swiper spaceBetween={20} slidesPerView={1} className="rounded-lg">
              {media.map((m) => (
                <SwiperSlide key={m.id}>
                  {m.tipo === "imagen" ? (
                    <img
                      src={`http://localhost:8000/${m.file_path}`}
                      className="w-full rounded-lg"
                      alt="media"
                    />
                  ) : (
                    <video
                      src={`http://localhost:8000/${m.file_path}`}
                      className="w-full rounded-lg"
                      controls
                    />
                  )}
                </SwiperSlide>
              ))}
            </Swiper>
          )}
        </div>
      </main>
    </>
  );
}
