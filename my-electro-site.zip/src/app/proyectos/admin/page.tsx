"use client";

import { useState } from "react";

export default function AdminProyectosPage() {
  const [titulo, setTitulo] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      console.log("🚀 Creando proyecto:", { titulo, descripcion });

      // 1️⃣ Crear proyecto en backend
      const res = await fetch("http://localhost:8000/projects/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titulo, descripcion }),
      });

      if (!res.ok) {
        console.error("❌ Error creando proyecto:", res.status, await res.text());
        alert("Error al crear proyecto");
        return;
      }

      const project = await res.json();
      console.log("✅ Proyecto creado:", project);

      // 2️⃣ Subir imágenes/videos si hay archivos seleccionados
      if (selectedFiles.length > 0) {
        for (const file of selectedFiles) {
          console.log("📂 Subiendo archivo:", file.name);
          const formData = new FormData();
          formData.append("file", file);

          const upload = await fetch(`http://localhost:8000/projects/${project.id}/media`, {
            method: "POST",
            body: formData,
          });

          if (!upload.ok) {
            console.error(`❌ Error subiendo ${file.name}:`, upload.status, await upload.text());
            alert(`Error subiendo archivo: ${file.name}`);
            continue;
          }

          console.log(`✅ Archivo subido: ${file.name}`);
        }
      } else {
        console.log("ℹ️ No hay archivos para subir.");
      }

      alert("Proyecto creado con éxito 🚀");
      setTitulo("");
      setDescripcion("");
      setSelectedFiles([]);
    } catch (err) {
      console.error("❌ Error en handleSubmit:", err);
      alert("Hubo un error en la creación del proyecto");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-10">
      <h1 className="text-3xl font-bold text-cyan-400 mb-6">Administrador de Proyectos</h1>
      <form onSubmit={handleSubmit} className="space-y-4 max-w-xl mx-auto bg-gray-800 p-6 rounded-lg shadow-lg">
        <input
          type="text"
          placeholder="Título del proyecto"
          className="w-full p-2 rounded bg-gray-700"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          required
        />
        <textarea
          placeholder="Descripción"
          className="w-full p-2 rounded bg-gray-700"
          value={descripcion}
          onChange={(e) => setDescripcion(e.target.value)}
          required
        />
        <input
          type="file"
          multiple
          onChange={handleFileChange}
          className="w-full text-gray-300"
        />
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-cyan-600 hover:bg-cyan-700 py-2 rounded font-bold"
        >
          {loading ? "Creando..." : "Crear Proyecto"}
        </button>
      </form>

      {/* Previsualización de archivos seleccionados */}
      {selectedFiles.length > 0 && (
        <div className="mt-6 max-w-xl mx-auto">
          <h2 className="text-lg font-semibold text-cyan-300 mb-2">Archivos seleccionados:</h2>
          <ul className="space-y-1 text-gray-300">
            {selectedFiles.map((file, i) => (
              <li key={i}>{file.name}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
