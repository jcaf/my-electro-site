"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "@/components/Navbar";

interface Project {
  id: number;
  titulo: string;
  descripcion: string;
  imagen_path?: string;
  video_path?: string;
}

export default function ProyectosPage() {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    fetch("http://localhost:8000/projects/")
      .then((res) => res.json())
      .then((data) => setProjects(data));
  }, []);

  return (
    <>
      <Navbar />
      <main className="bg-gradient-to-br from-black via-gray-900 to-gray-800 min-h-screen p-10 text-white">
        <h1 className="text-4xl font-bold text-cyan-400 text-center mb-10">Proyectos Realizados</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {projects.map((p) => (
            <Link key={p.id} href={`/proyectos/${p.id}`}>
              <div className="bg-gray-900 border border-gray-700 rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition cursor-pointer">
                {p.imagen_path ? (
                  <img src={`http://localhost:8000/${p.imagen_path}`} className="w-full h-48 object-cover" />
                ) : p.video_path ? (
                  <video src={`http://localhost:8000/${p.video_path}`} className="w-full h-48 object-cover" controls />
                ) : (
                  <div className="w-full h-48 bg-gray-700 flex items-center justify-center text-gray-400">Sin Imagen</div>
                )}
                <div className="p-4">
                  <h2 className="text-xl font-semibold text-cyan-300">{p.titulo}</h2>
                  <p className="text-gray-300 text-sm mt-2">{p.descripcion}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </>
  );
}
